﻿using Microsoft.EntityFrameworkCore;
using AddMultipleProducts.Models;

namespace AddMultipleProducts.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
    }
}
