﻿const apiBaseUrl = 'https://localhost:7132/api/Products';

document.getElementById('addProductForm').addEventListener('submit', function (event) {
    event.preventDefault();
    const product = {
        name: document.getElementById('productName').value,
        productCode: document.getElementById('productCode').value,
        expirationDate: document.getElementById('expirationDate').value,
        manufacturingDate: document.getElementById('manufacturingDate').value,
        createdOn: document.getElementById('createdOn').value,
        createdBy: document.getElementById('createdBy').value,
        details: document.getElementById('details').value,
        status: document.getElementById('status').value
    };
    addProduct(product);
});

document.getElementById('editProductForm').addEventListener('submit', function (event) {
    event.preventDefault();
    const productId = document.getElementById('editProductId').value;
    const product = {
        id: productId,
        name: document.getElementById('editProductName').value,
        productCode: document.getElementById('editProductCode').value,
        expirationDate: document.getElementById('editExpirationDate').value,
        manufacturingDate: document.getElementById('editManufacturingDate').value,
        createdOn: document.getElementById('editCreatedOn').value,
        createdBy: document.getElementById('editCreatedBy').value,
        details: document.getElementById('editDetails').value,
        status: document.getElementById('editStatus').value
    };
    updateProduct(productId, product);
});

function addProduct() {
    const product = {
        name: document.getElementById('productName').value,
        productCode: document.getElementById('productCode').value,
        expirationDate: document.getElementById('expirationDate').value,
        manufacturingDate: document.getElementById('manufacturingDate').value,
        createdOn: document.getElementById('createdOn').value,
        createdBy: document.getElementById('createdBy').value,
        details: document.getElementById('details').value,
        status: document.getElementById('status').value
    };

    fetch('https://localhost:7132/api/Products', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(product)
    })
        .then(response => {
            if (!response.ok) {
                return response.text().then(text => { throw new Error(text); });
            }
            return response.json();
        })
        .then(data => {
            console.log('Product added successfully:', data);
            $('#addProductModal').modal('hide');
            fetchProducts();
        })
        .catch(error => {
            console.error('Error adding product:', error);
            alert('Failed to add product. ' + error.message);
        });
}




function updateProduct(productId, product) {
    fetch(`${apiBaseUrl}/${productId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(product)
    })
        .then(response => {
            if (!response.ok) {
                return response.text().then(text => { throw new Error(text); });
            }
            // Check if there is a response body
            if (response.status !== 204) {
                return response.json();
            }
            return null;  // No content
        })
        .then(data => {
            $('#editProductModal').modal('hide');
            fetchProducts();
            alert('Product updated successfully!');
        })
        .catch(error => {
            console.error('Error updating product:', error);
            alert('Failed to update product. ' + error.message);
        });
}


function fetchProducts() {
    fetch(apiBaseUrl)
        .then(response => response.json())
        .then(data => {
            const productTableBody = document.querySelector('#productTable tbody');
            productTableBody.innerHTML = '';
            data.forEach(product => {
                const row = document.createElement('tr');
                row.innerHTML = `
                <td>${product.id}</td>
                <td>${product.name}</td>
                <td>${product.productCode}</td>
                <td>${product.expirationDate}</td>
                <td>${product.manufacturingDate}</td>
                <td>${product.createdOn}</td>
                <td>${product.createdBy}</td>
                <td>${product.details}</td>
                <td>${product.status}</td>
                <td>
                    <button class="btn btn-warning btn-sm" onclick="editProduct(${product.id})">Edit</button>
                    <button class="btn btn-danger btn-sm" onclick="deleteProduct(${product.id})">Delete</button>
                </td>
            `;
                productTableBody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Error fetching products:', error);
        });
}

function editProduct(productId) {
    fetch(`${apiBaseUrl}/${productId}`)
        .then(response => response.json())
        .then(product => {
            document.getElementById('editProductId').value = product.id;
            document.getElementById('editProductName').value = product.name;
            document.getElementById('editProductCode').value = product.productCode;
            document.getElementById('editExpirationDate').value = product.expirationDate;
            document.getElementById('editManufacturingDate').value = product.manufacturingDate;
            document.getElementById('editCreatedOn').value = product.createdOn;
            document.getElementById('editCreatedBy').value = product.createdBy;
            document.getElementById('editDetails').value = product.details;
            document.getElementById('editStatus').value = product.status;
            $('#editProductModal').modal('show');
        })
        .catch(error => {
            console.error('Error fetching product:', error);
        });
}

function deleteProduct(productId) {
    fetch(`${apiBaseUrl}/${productId}`, {
        method: 'DELETE'
    })
        .then(response => {
            if (!response.ok) {
                return response.text().then(text => { throw new Error(text); });
            }
            fetchProducts();
            alert('Product deleted successfully!');
        })
        .catch(error => {
            console.error('Error deleting product:', error);
            alert('Failed to delete product. ' + error.message);
        });
}

document.addEventListener('DOMContentLoaded', fetchProducts);
