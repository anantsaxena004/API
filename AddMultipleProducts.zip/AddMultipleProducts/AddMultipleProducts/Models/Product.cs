﻿using System.ComponentModel.DataAnnotations;

namespace AddMultipleProducts.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ProductCode { get; set; }
        public DateOnly ExpirationDate { get; set; }
        public DateOnly ManufacturingDate { get; set; }
        public DateOnly CreateOn { get; set; }
        public string CreatedBy { get; set; }
        public string Details { get; set; }
        public string Status { get; set; }
    }
}
