document.addEventListener('DOMContentLoaded', async function() {
    const productSelect = document.getElementById('productSelect');
    try {
        const response = await fetch('https://localhost:7297/api/Products');
        const products = await response.json();

        products.forEach(product => {
            const option = document.createElement('option');
            option.value = product.id;
            option.text = product.name;
            productSelect.add(option);
        });
    } catch (error) {
        console.error('Fetch error:', error);
        alert('An error occurred while fetching products. Please try again.');
    }
});

document.getElementById('addProductForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const userID = sessionStorage.getItem('userID'); // Assuming you store userID in sessionStorage after login
    const productID = document.getElementById('productSelect').value;
    const quantity = document.getElementById('quantity').value;

    try {
        const response = await fetch('https://localhost:7297/api/UserProducts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userID,
                products: [{ productID, quantity }]
            })
        });

        if (response.ok) {
            alert('Product added successfully.');
        } else {
            const errorData = await response.json();
            console.error('Error:', errorData);
            alert(`Error: ${errorData.title}`);
        }
    } catch (error) {
        console.error('Fetch error:', error);
        alert('An error occurred while adding the product. Please try again.');
    }
});
