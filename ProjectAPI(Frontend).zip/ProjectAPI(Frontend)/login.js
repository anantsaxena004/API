document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const userId = document.getElementById('loginUserId').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const response = await fetch(`https://localhost:7297/api/Users/${userId}`);
        
        if (!response.ok) {
            const errorData = await response.json();
            console.error('Error:', errorData);
            alert(`Error: ${errorData.title}`);
            return;
        }

        const user = await response.json();

        if (user && user.password === password) {
            sessionStorage.setItem('userID', userId);  // Store userID in sessionStorage for later use
            window.location.href = 'addproduct.html';
        } else {
            alert('User not found. Please register first.');
        }
    } catch (error) {
        console.error('Fetch error:', error);
        alert('An error occurred while logging in. Please try again.');
    }
});

document.getElementById('registerForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const userName = document.getElementById('registerUserName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;

    try {
        const response = await fetch('https://localhost:7297/api/Users', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ userName, email, password })
        });

        if (response.ok) {
            alert('User registered successfully. You can now login.');
        } else {
            const errorData = await response.json();
            console.error('Error:', errorData);
            alert(`Error: ${errorData.title}`);
        }
    } catch (error) {
        console.error('Fetch error:', error);
        alert('An error occurred while registering. Please try again.');
    }
});
