﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProjectAPI.Models;

[Route("api/[controller]")]
[ApiController]
public class UserProductsController : ControllerBase
{
    private readonly AppDbContext _context;

    public UserProductsController(AppDbContext context)
    {
        _context = context;
    }

    // GET: api/UserProducts
    [HttpGet]
    public async Task<ActionResult<IEnumerable<UserProduct>>> GetUserProducts()
    {
        return await _context.UserProducts.Include(up => up.User).Include(up => up.Product).ToListAsync();
    }

    // GET: api/UserProducts/5
    [HttpGet("{id}")]
    public async Task<ActionResult<UserProduct>> GetUserProduct(int id)
    {
        var userProduct = await _context.UserProducts
            .Include(up => up.User)
            .Include(up => up.Product)
            .FirstOrDefaultAsync(up => up.ID == id);

        if (userProduct == null)
        {
            return NotFound();
        }

        return userProduct;
    }

    // POST: api/UserProducts
    [HttpPost]
    public async Task<ActionResult<UserProduct>> PostUserProduct(UserProduct userProduct)
    {
        _context.UserProducts.Add(userProduct);
        await _context.SaveChangesAsync();

        return CreatedAtAction("GetUserProduct", new { id = userProduct.ID }, userProduct);
    }

    // PUT: api/UserProducts/5
    [HttpPut("{id}")]
    public async Task<IActionResult> PutUserProduct(int id, UserProduct userProduct)
    {
        if (id != userProduct.ID)
        {
            return BadRequest();
        }

        _context.Entry(userProduct).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!UserProductExists(id))
            {
                return NotFound();
            }
            else
            {
                throw;
            }
        }

        return NoContent();
    }

    // DELETE: api/UserProducts/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteUserProduct(int id)
    {
        var userProduct = await _context.UserProducts.FindAsync(id);
        if (userProduct == null)
        {
            return NotFound();
        }

        _context.UserProducts.Remove(userProduct);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    private bool UserProductExists(int id)
    {
        return _context.UserProducts.Any(e => e.ID == id);
    }
}
