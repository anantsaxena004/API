document.getElementById('viewProductsForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    const userID = document.getElementById('userID').value;
    try {
        const response = await fetch(`https://localhost:7297/api/UserProducts?userID=${userID}`);

        if (!response.ok) {
            const errorData = await response.json();
            console.error('Error:', errorData);
            alert(`Error: ${errorData.title}`);
            return;
        }

        const userProducts = await response.json();

        const productsTable = document.getElementById('productsTable').getElementsByTagName('tbody')[0];
        productsTable.innerHTML = '';

        userProducts.forEach(userProduct => {
            const row = productsTable.insertRow();
            row.insertCell(0).innerText = userProduct.product.name;
            row.insertCell(1).innerText = userProduct.quantity;
            row.insertCell(2).innerText = userProduct.totalAmount;
        });
    } catch (error) {
        console.error('Fetch error:', error);
        alert('An error occurred while fetching products. Please try again.');
    }
});
