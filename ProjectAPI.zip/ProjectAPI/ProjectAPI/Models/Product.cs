﻿namespace ProjectAPI.Models

{
    public class Product
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string ProductCode { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public DateTime? ManufacturingDate { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public string Details { get; set; }
        public string Status { get; set; }
        public ICollection<UserProduct> UserProducts { get; set; }
    }
}
